# TaskManagement.API (Backend)
## Quick start
- Requires .NET 7 SDK and SQL Server (LocalDB works)
- From `backend/TaskManagement.API`:
  - `dotnet restore`
  - `dotnet run`
- Default connection uses LocalDB: change `appsettings.json` -> ConnectionStrings:DefaultConnection

This API supports:
- User register/login (returns JWT)
- CRUD for tasks (authorized)
- Serilog request logging
- EF Core EnsureCreated to build DB automatically
