
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagement.API.Data;
using TaskManagement.API.Models;
using System.Security.Claims;

namespace TaskManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class TasksController : ControllerBase
    {
        private readonly AppDbContext _ctx;
        public TasksController(AppDbContext ctx) { _ctx = ctx; }

        [HttpGet]
        public async Task<IActionResult> GetTasks()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var role = User.FindFirstValue(ClaimTypes.Role);
            IQueryable<TaskItem> q = _ctx.Tasks.Include(t => t.Assignee);
            if (role != "Admin")
            {
                q = q.Where(t => t.AssigneeId == userId || t.AssigneeId == null);
            }
            var list = await q.OrderByDescending(t => t.CreatedAt).ToListAsync();
            return Ok(list);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var task = await _ctx.Tasks.Include(t => t.Assignee).FirstOrDefaultAsync(t => t.Id == id);
            if (task == null) return NotFound();
            return Ok(task);
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateTaskDto dto)
        {
            var task = new TaskItem
            {
                Title = dto.Title,
                Description = dto.Description,
                Priority = dto.Priority,
                DueDate = dto.DueDate,
                Category = dto.Category,
                AssigneeId = dto.AssigneeId
            };
            _ctx.Tasks.Add(task);
            await _ctx.SaveChangesAsync();
            return Ok(task);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, CreateTaskDto dto)
        {
            var task = await _ctx.Tasks.FindAsync(id);
            if (task == null) return NotFound();
            task.Title = dto.Title;
            task.Description = dto.Description;
            task.Priority = dto.Priority;
            task.DueDate = dto.DueDate;
            task.Category = dto.Category;
            task.AssigneeId = dto.AssigneeId;
            await _ctx.SaveChangesAsync();
            return Ok(task);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var task = await _ctx.Tasks.FindAsync(id);
            if (task == null) return NotFound();
            _ctx.Tasks.Remove(task);
            await _ctx.SaveChangesAsync();
            return NoContent();
        }
    }

    public record CreateTaskDto(string Title, string? Description, int Priority, DateTime? DueDate, string? Category, int? AssigneeId);
}
