
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagement.API.Data;

namespace TaskManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _ctx;
        public UsersController(AppDbContext ctx) { _ctx = ctx; }

        [HttpGet("me")]
        public async Task<IActionResult> Me()
        {
            var idStr = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (idStr == null) return Unauthorized();
            var id = int.Parse(idStr);
            var user = await _ctx.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == id);
            if (user == null) return NotFound();
            return Ok(new { user.Id, user.Email, user.FullName, Role = user.Role?.Name });
        }
    }
}
