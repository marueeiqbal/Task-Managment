
using Microsoft.AspNetCore.Mvc;
using TaskManagement.API.Services;
using TaskManagement.API.Data;
using TaskManagement.API.Models;

namespace TaskManagement.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _auth;
        public AuthController(AuthService auth) { _auth = auth; }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto dto)
        {
            var user = await _auth.Register(dto.Email, dto.Password, dto.FullName);
            if (user == null) return BadRequest(new { message = "Email already in use" });
            return Ok(new { user.Id, user.Email, user.FullName });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var token = await _auth.Login(dto.Email, dto.Password);
            if (token == null) return Unauthorized(new { message = "Invalid credentials" });
            return Ok(new { token });
        }
    }

    public record RegisterDto(string Email, string Password, string? FullName);
    public record LoginDto(string Email, string Password);
}
