
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TaskManagement.API.Models
{
    public enum TaskStatus { Pending = 0, InProgress = 1, Completed = 2 }

    public class TaskItem
    {
        public int Id { get; set; }
        [Required, MaxLength(500)]
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public TaskStatus Status { get; set; } = TaskStatus.Pending;
        public int Priority { get; set; } = 0;
        public DateTime? DueDate { get; set; }
        [ForeignKey("Assignee")]
        public int? AssigneeId { get; set; }
        public User? Assignee { get; set; }
        public string? Category { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
