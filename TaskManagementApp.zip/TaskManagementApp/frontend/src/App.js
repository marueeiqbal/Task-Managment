
import React, { useState, useEffect } from "react";
import axios from "axios";

const API = "http://localhost:5000/api";

function Login({ onToken }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  async function submit(e) {
    e.preventDefault();
    const res = await axios.post(`${API}/auth/login`, { email, password });
    onToken(res.data.token);
  }
  return (
    <form onSubmit={submit}>
      <h3>Login</h3>
      <input placeholder="email" value={email} onChange={e => setEmail(e.target.value)} />
      <input placeholder="password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
      <button>Login</button>
    </form>
  );
}

function Dashboard({ token }) {
  const [tasks, setTasks] = useState([]);
  useEffect(() => {
    axios.get(`${API}/tasks`, { headers: { Authorization: `Bearer ${token}`}}).then(r => setTasks(r.data));
  }, [token]);
  return (
    <div>
      <h2>Dashboard</h2>
      <ul>
        {tasks.map(t => <li key={t.id}>{t.title} - {t.status}</li>)}
      </ul>
    </div>
  )
}

function App() {
  const [token, setToken] = useState(null);
  return (
    <div style={{padding:20}}>
      {!token ? <Login onToken={setToken} /> : <Dashboard token={token} />}
    </div>
  );
}

export default App;
