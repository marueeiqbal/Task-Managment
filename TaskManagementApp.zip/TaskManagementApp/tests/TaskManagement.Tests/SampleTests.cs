using Xunit;
public class SampleTests { [Fact] public void TrueIsTrue() { Assert.True(true); } }